﻿export class Name {

    get message() {
        return "Other Name";
    }
}
